package com.example.click_counter_by_date;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private TextView dailyTextView, weeklyTextView, monthlyTextView;
    private int dailyCount, weeklyCount, monthlyCount;
    private long lastSavedTime;
    private SharedPreferences sharedPreferences;
    private Clock clock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dailyTextView = findViewById(R.id.dailyTextView);
        weeklyTextView = findViewById(R.id.weeklyTextView);
        monthlyTextView = findViewById(R.id.monthlyTextView);
        Button incrementButton = findViewById(R.id.incrementButton);

        sharedPreferences = getSharedPreferences(Constants.PREFS_NAME, MODE_PRIVATE);

        // Load the last saved time from SharedPreferences
        lastSavedTime = sharedPreferences.getLong(Constants.LAST_SAVED_TIME_KEY, 0);

        // Load previous counts from SharedPreferences
        dailyCount = sharedPreferences.getInt(Constants.DAILY_COUNT_KEY, 0);
        weeklyCount = sharedPreferences.getInt(Constants.WEEKLY_COUNT_KEY, 0);
        monthlyCount = sharedPreferences.getInt(Constants.MONTHLY_COUNT_KEY, 0);

        // Use the SystemClock as the default clock implementation
        clock = new SystemClock();

        // Check and reset the counters if needed
        checkAndResetCounters();
        // Update the TextViews with the current counts
        updateTextViews();

        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Increment the daily count
                dailyCount++;
                // Increment the weekly count
                weeklyCount++;
                // Increment the monthly count
                monthlyCount++;
                // Save the updated counts to SharedPreferences
                saveCountsToSharedPreferences();
                // Update the TextViews with the new counts
                updateTextViews();
            }
        });
    }

    void checkAndResetCounters() {
        Calendar calendar = Calendar.getInstance();
        long currentTime = calendar.getTimeInMillis();

        if (currentTime >= getLastResetTime(Calendar.DAY_OF_MONTH)) {
            // Reset daily counter
            dailyCount = 0;
        }

        if (currentTime >= getLastResetTime(Calendar.WEEK_OF_YEAR)) {
            // Reset weekly counter
            weeklyCount = 0;
        }

        if (currentTime >= getLastResetTime(Calendar.MONTH)) {
            // Reset monthly counter
            monthlyCount = 0;
        }

        // Update the last saved time if any counter was reset
        if (dailyCount == 0 || weeklyCount == 0 || monthlyCount == 0) {
            lastSavedTime = currentTime;
        }
    }
    void setClock(Clock clock) {
        this.clock = clock;
    }

    private long getLastResetTime(int interval) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(lastSavedTime);
        switch (interval) {
            case Calendar.DAY_OF_MONTH:
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                calendar.add(Calendar.DAY_OF_MONTH, 1);
                break;
            case Calendar.WEEK_OF_YEAR:
                calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                calendar.add(Calendar.WEEK_OF_YEAR, 1);
                break;
            case Calendar.MONTH:
                calendar.set(Calendar.DAY_OF_MONTH, 1);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);
                calendar.add(Calendar.MONTH, 1);
                break;
        }
        return calendar.getTimeInMillis();
    }

    private void saveCountsToSharedPreferences() {
        sharedPreferences.edit()
                .putInt(Constants.DAILY_COUNT_KEY, dailyCount)
                .putInt(Constants.WEEKLY_COUNT_KEY, weeklyCount)
                .putInt(Constants.MONTHLY_COUNT_KEY, monthlyCount)
                .putLong(Constants.LAST_SAVED_TIME_KEY, lastSavedTime)
                .apply();
    }

    private void updateTextViews() {
        dailyTextView.setText(String.valueOf(dailyCount));
        weeklyTextView.setText(String.valueOf(weeklyCount));
        monthlyTextView.setText(String.valueOf(monthlyCount));
    }
}
