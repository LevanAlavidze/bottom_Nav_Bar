package com.example.click_counter_by_date;

public interface Clock {
    long currentTimeMillis();
}
